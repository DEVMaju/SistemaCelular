using System;
using SistemaCelular.Models;

class Program
{
    static void Main()
    {
        Celular meuSamsung = new Samsung("Galaxy S23", "Preto");
        Celular meuIphone = new Iphone("iPhone 14", "Branco");

        meuSamsung.Ligar();
        meuIphone.Ligar();

        meuSamsung.EnviarMensagem("Olá, Samsung!");
        meuIphone.EnviarMensagem("Olá, iPhone!");

        meuSamsung.Desligar();
        meuIphone.Desligar();
    }
}