using System;

namespace SistemaCelular.Models
{
    public abstract class Celular
    {
        public string Modelo { get; set; }
        public string Cor { get; set; }

        public Celular(string modelo, string cor)
        {
            Modelo = modelo;
            Cor = cor;
        }

        public abstract void Ligar();
        public abstract void Desligar();

        public void EnviarMensagem(string mensagem)
        {
            Console.WriteLine($"Mensagem enviada: {mensagem}");
        }
    }
}