# Sistema de Celulares

Projeto em C#/.NET que abstrai o conceito de celular utilizando Programação Orientada a Objetos (POO). 

Funcionalidades:
- Classe abstrata `Celular` definindo modelo, cor e métodos abstratos para ligar e desligar.
- Classes concretas `Samsung` e `Iphone` implementando comportamentos específicos.
- Método comum para enviar mensagens a todos os celulares.
- Demonstração de abstração, herança e polimorfismo.

Tecnologias:
- C# / .NET
- POO
- Git e GitHub para versionamento